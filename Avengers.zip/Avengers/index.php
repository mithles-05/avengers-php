<?php

require_once "db.php";

$sql = "SELECT id, name, real_name, power, image
        FROM avengers
        ORDER BY id DESC";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Avengers Database</title>

    <link rel="stylesheet" href="style.css">

</head>

<body>

<!-- =====================================================
     BACKGROUND EFFECTS
     ===================================================== -->

<div class="energy energy-red"></div>
<div class="energy energy-blue"></div>
<div class="energy energy-gold"></div>


<!-- =====================================================
     MAIN
     ===================================================== -->

<main class="main-container">


    <!-- =================================================
         HERO HEADER
         ================================================= -->

    <section class="hero">

        <div class="hero-content">

            <div class="hero-tag">
                S.H.I.E.L.D. // CLASSIFIED DATABASE
            </div>

            <h1>
                AVENGERS
            </h1>

            <div class="hero-line"></div>

            <p>
                EARTH'S MIGHTIEST HEROES
            </p>

        </div>


        <!-- Arc Reactor -->

        <div class="reactor">

            <div class="reactor-ring ring-1"></div>
            <div class="reactor-ring ring-2"></div>
            <div class="reactor-ring ring-3"></div>

            <div class="reactor-core">
        <img
        src="images/avengers-logo.svg"
        alt="Avengers Logo"
        >
        </div>

        </div>

    </section>


    <!-- =================================================
         DATABASE HEADER
         ================================================= -->

    <section class="database-header">

        <div>

            <span class="section-label">
                AVENGERS DATABASE
            </span>

            <h2>
                ACTIVE OPERATIVES
            </h2>

        </div>

        <a href="add.php" class="add-btn">
            <span>+</span>
            ADD AVENGER
        </a>

    </section>


    <!-- =================================================
         AVENGER CARDS
         ================================================= -->

    <section class="avenger-grid">

        <?php if ($result->num_rows > 0): ?>

            <?php while ($avenger = $result->fetch_assoc()): ?>

                <article class="avenger-card">


                    <!-- Image -->

                    <div class="character-image">

                        <img
                            src="<?= htmlspecialchars($avenger["image"]) ?>"
                            alt="<?= htmlspecialchars($avenger["name"]) ?>"
                        >

                        <div class="image-overlay"></div>

                        <div class="character-number">

                            #<?= htmlspecialchars($avenger["id"]) ?>

                        </div>

                    </div>


                    <!-- Information -->

                    <div class="character-info">


                        <div class="character-status">

                            <span class="status-dot"></span>

                            ACTIVE

                        </div>


                        <h3>

                            <?= htmlspecialchars($avenger["name"]) ?>

                        </h3>


                        <p class="real-name">

                            <?= htmlspecialchars($avenger["real_name"]) ?>

                        </p>


                        <div class="power-box">

                            <span class="power-label">
                                POWER
                            </span>

                            <span class="power-value">

                                <?= htmlspecialchars($avenger["power"]) ?>

                            </span>

                        </div>


                        <!-- Actions -->

                        <div class="card-actions">

                            <a
                                href="edit.php?id=<?= $avenger["id"] ?>"
                                class="edit-btn"
                            >
                                EDIT
                            </a>

                            <a
                                href="delete.php?id=<?= $avenger["id"] ?>"
                                class="delete-btn"
                                onclick="return confirm('Are you sure you want to remove this Avenger?');"
                            >
                                DELETE
                            </a>

                        </div>

                    </div>

                </article>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty-state">

                <div class="empty-icon">
                    A
                </div>

                <h3>
                    NO ACTIVE AVENGERS
                </h3>

                <p>
                    Add the first member to the Avengers database.
                </p>

                <a href="add.php" class="add-btn">
                    + ADD AVENGER
                </a>

            </div>

        <?php endif; ?>

    </section>


    <!-- =================================================
         FOOTER
         ================================================= -->

    <footer>

        <span>
            S.H.I.E.L.D. SECURE SYSTEM
        </span>

        <span>
            •
        </span>

        <span>
            AVENGERS INITIATIVE
        </span>

        <span>
            •
        </span>

        <span>
            DATABASE ONLINE
        </span>

    </footer>

</main>

</body>

</html>

<?php

$conn->close();

?>