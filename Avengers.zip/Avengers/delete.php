<?php

require_once "db.php";

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id) {
    die("Invalid Avenger ID.");
}

$sql = "DELETE FROM avengers WHERE id = ?";

$stmt = $conn->prepare($sql);

$stmt->bind_param("i", $id);

$stmt->execute();

$stmt->close();

$conn->close();

header("Location: index.php");
exit;

?>