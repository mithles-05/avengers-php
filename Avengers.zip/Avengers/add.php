<?php

require_once "db.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $real_name = trim($_POST["real_name"] ?? "");
    $power = trim($_POST["power"] ?? "");
    $image = trim($_POST["image"] ?? "");

    if ($name === "" || $real_name === "" || $power === "" || $image === "") {

        $error = "All fields are required.";

    } else {

        $sql = "INSERT INTO avengers (name, real_name, power, image)
                VALUES (?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);

        $stmt->bind_param(
            "ssss",
            $name,
            $real_name,
            $power,
            $image
        );

        if ($stmt->execute()) {

            header("Location: index.php");
            exit;

        } else {

            $error = "Failed to add Avenger.";
        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Add Avenger</title>

    <link rel="stylesheet" href="style.css">

</head>

<body>

<div class="form-container">

    <h1>⚡ Add Avenger</h1>

    <?php if ($error): ?>

        <p class="error">
            <?= htmlspecialchars($error) ?>
        </p>

    <?php endif; ?>

    <form method="POST">

        <!-- Avenger Name -->

        <label>Avenger Name</label>

        <input
            type="text"
            name="name"
            placeholder="Iron Man"
            required
        >


        <!-- Real Name -->

        <label>Real Name</label>

        <input
            type="text"
            name="real_name"
            placeholder="Tony Stark"
            required
        >


        <!-- Power -->

        <label>Power</label>

        <input
            type="text"
            name="power"
            placeholder="Technology"
            required
        >


        <!-- Image -->

        <label>Image URL</label>

        <input
            type="url"
            name="image"
            placeholder="https://example.com/iron-man.jpg"
            required
        >


        <!-- Submit -->

        <button type="submit">
            ⚡ Add Avenger
        </button>

    </form>

    <a href="index.php" class="back-btn">
        ← Back
    </a>

</div>

</body>

</html>