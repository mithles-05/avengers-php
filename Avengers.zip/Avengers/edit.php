<?php

require_once "db.php";

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id) {
    die("Invalid Avenger ID.");
}

/*
 * Fetch existing Avenger
 */

$sql = "SELECT id, name, real_name, power
        FROM avengers
        WHERE id = ?";

$stmt = $conn->prepare($sql);

$stmt->bind_param("i", $id);

$stmt->execute();

$result = $stmt->get_result();

$avenger = $result->fetch_assoc();

$stmt->close();

if (!$avenger) {
    die("Avenger not found.");
}

$error = "";

/*
 * Update Avenger
 */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $real_name = trim($_POST["real_name"] ?? "");
    $power = trim($_POST["power"] ?? "");

    if ($name === "" || $real_name === "" || $power === "") {

        $error = "All fields are required.";

    } else {

        $sql = "UPDATE avengers
                SET name = ?, real_name = ?, power = ?
                WHERE id = ?";

        $stmt = $conn->prepare($sql);

        $stmt->bind_param(
            "sssi",
            $name,
            $real_name,
            $power,
            $id
        );

        if ($stmt->execute()) {

            header("Location: index.php");
            exit;

        } else {

            $error = "Failed to update Avenger.";
        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Edit Avenger</title>

    <link rel="stylesheet" href="style.css">

</head>

<body>

<div class="form-container">

    <h1>Edit Avenger</h1>

    <?php if ($error): ?>

        <p class="error">
            <?= htmlspecialchars($error) ?>
        </p>

    <?php endif; ?>

    <form method="POST">

        <label>Avenger Name</label>

        <input
            type="text"
            name="name"
            value="<?= htmlspecialchars($avenger["name"]) ?>"
            required
        >

        <label>Real Name</label>

        <input
            type="text"
            name="real_name"
            value="<?= htmlspecialchars($avenger["real_name"]) ?>"
            required
        >

        <label>Power</label>

        <input
            type="text"
            name="power"
            value="<?= htmlspecialchars($avenger["power"]) ?>"
            required
        >

        <button type="submit">
            Update Avenger
        </button>

    </form>

    <a href="index.php" class="back-btn">
        ← Back
    </a>

</div>

</body>

</html>